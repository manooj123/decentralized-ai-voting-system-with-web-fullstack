---
name: Digital Fortress
colors:
  surface: '#101415'
  surface-dim: '#101415'
  surface-bright: '#363a3b'
  surface-container-lowest: '#0b0f10'
  surface-container-low: '#191c1e'
  surface-container: '#1d2022'
  surface-container-high: '#272a2c'
  surface-container-highest: '#323537'
  on-surface: '#e0e3e5'
  on-surface-variant: '#bec8d2'
  inverse-surface: '#e0e3e5'
  inverse-on-surface: '#2d3133'
  outline: '#88929b'
  outline-variant: '#3e4850'
  surface-tint: '#89ceff'
  primary: '#89ceff'
  on-primary: '#00344d'
  primary-container: '#0ea5e9'
  on-primary-container: '#003751'
  inverse-primary: '#006591'
  secondary: '#bec6e0'
  on-secondary: '#283044'
  secondary-container: '#3f465c'
  on-secondary-container: '#adb4ce'
  tertiary: '#bcc7de'
  on-tertiary: '#263143'
  tertiary-container: '#919cb2'
  on-tertiary-container: '#293446'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c9e6ff'
  primary-fixed-dim: '#89ceff'
  on-primary-fixed: '#001e2f'
  on-primary-fixed-variant: '#004c6e'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#d8e3fb'
  tertiary-fixed-dim: '#bcc7de'
  on-tertiary-fixed: '#111c2d'
  on-tertiary-fixed-variant: '#3c475a'
  background: '#101415'
  on-background: '#e0e3e5'
  surface-variant: '#323537'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 40px
---

## Brand & Style
The design system is engineered to evoke "Digital Fortress meets Transparent Democracy." It targets a global electorate demanding absolute security, cryptographic proof, and extreme clarity. The visual language blends **Modern Corporate** reliability with **Minimalist** precision to ensure the interface feels institutional yet accessible.

The emotional response should be one of "Unshakable Trust." This is achieved through a structural layout, high-contrast readability, and a lack of decorative flourish. Every element serves a functional purpose, mirroring the immutable nature of the blockchain.

## Colors
The palette is rooted in a "Deep Space" dark mode to reduce eye strain during long-form reading and to emphasize the glowing clarity of the data. 

- **Primary (#0EA5E9):** A trustworthy Cyan used for primary actions, progress indicators, and "On-Chain" confirmations.
- **Secondary (#0F172A):** The "Fortress" base. Used for the main background to provide a sense of depth and stability.
- **Tertiary (#1E293B):** Used for card surfaces and elevated containers to create a clear visual hierarchy.
- **Neutral (#F8FAFC):** Reserved for high-contrast typography and essential icons to ensure maximum legibility against dark backgrounds.

## Typography
The system utilizes **Inter** for all primary interface elements to ensure clinical legibility across all device types. For cryptographic strings, transaction hashes, and status labels, **JetBrains Mono** is employed to signal "Technical Veracity" and distinguish machine-generated data from human-centric content.

- Use **Bold** weights sparingly for navigation and section headers.
- **JetBrains Mono** should be used for all "Verified," "On-Chain," and hash-based labels to reinforce the developer-grade security of the system.

## Layout & Spacing
The design system follows a strict **8px grid** to maintain mathematical alignment. On mobile, the layout utilizes a fluid 4-column system with 20px side margins to prevent content from touching the screen edges.

- **Stacking:** Vertical spacing between cards should consistently be 16px (md).
- **Groupings:** Related input fields should be grouped with 8px (sm) spacing.
- **Safe Areas:** Ensure bottom navigation and action buttons respect device-specific home indicators and notches.

## Elevation & Depth
This design system avoids traditional drop shadows to maintain a "flat but layered" aesthetic. Depth is communicated through **Tonal Layers** and **Low-Contrast Outlines**.

- **Level 0 (Base):** Deep Navy (#0F172A).
- **Level 1 (Cards/Inputs):** Surface Blue (#1E293B).
- **Level 2 (Overlays/Modals):** Lighter Slate (#334155).
- **Outlines:** All interactive elements (inputs, cards) feature a 1px solid border (#334155). When focused or active, this border transitions to the Primary Cyan.

## Shapes
Shapes are defined as **Soft (1)**. A 4px (0.25rem) corner radius is the standard for buttons and input fields, while 8px (0.5rem) is used for cards. This slight rounding softens the technical nature of the app without compromising its professional, "fortress-like" structural integrity. High-radius or pill-shapes are strictly prohibited as they appear too casual for a democratic institution.

## Components

### Status Badges
Badges use `label-sm` (Monospaced) and a "Dimmed Fill" approach:
- **Verified:** Primary Cyan text on 10% opacity Primary background.
- **On-Chain:** Green text on 10% opacity Green background.
- **Anonymous:** Light Slate text on 10% opacity White background.

### Secure Input Fields
Inputs use the Level 1 Surface (#1E293B). Private key fields must include a "Mask/Unmask" toggle icon and a "Copy to Clipboard" utility. For biometric auth, use a centered, high-contrast fingerprint or face-scan glyph with a subtle Primary glow.

### Result Charts & AI-Insight Cards
- **Charts:** Use thin 1px strokes for axes and the Primary color for data lines/bars. Avoid 3D effects.
- **AI-Insight Cards:** Feature a Primary Cyan 2px left-border accent to distinguish them from standard election data.

### Buttons
- **Primary:** Solid Primary Cyan (#0EA5E9) with Black text for maximum contrast.
- **Secondary:** Outlined with Primary Cyan and Primary Cyan text.
- **Ghost:** No background, White text, used for "Cancel" or "Go Back."

### Bottom Navigation
The navigation bar is a solid Level 2 Surface (#334155) with no blur. Active icons are Primary Cyan; inactive icons are Slate-400. Labels use `label-sm` for a precise, technical feel.